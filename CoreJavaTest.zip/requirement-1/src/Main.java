import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter contact 1 detail:");
		String detail1=sc.nextLine();
		System.out.println("Enter contact 2 detail:");
		String detail2=sc.nextLine();
//		Grace,9898798652,grace@gmail.com,27/02/1987
		String[] arr1 = detail1.split(",");
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		Contact contact1=new Contact(arr1[0], arr1[1], arr1[2], sdf.parse(arr1[3]));
		String[] arr2 = detail2.split(",");
		Contact contact2=new Contact(arr2[0], arr2[1], arr2[2], sdf.parse(arr2[3]));
		if(contact1.equals(contact2))
		{
			System.out.println("Contact 1 is same as Contact 2");
		}else
		{
			System.out.println("Contact 1 and Contact 2 are different");
		}
	}
	

}
