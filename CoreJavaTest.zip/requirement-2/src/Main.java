import java.util.Scanner;

public class Main {

	static Boolean validateMobileNumber(String mobileNumber)
	{
		return false; //remove this line and write your code
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Mobile number to be validated:");
		String mobileNo=sc.nextLine();
		if(validateMobileNumber(mobileNo))
		{
			System.out.println("Mobile number is valid");
		}
		else
		{
			System.out.println("Mobile number is invalid");
		}
	}

}
